# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['shyp']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'shyp',
    'version': '0.1.0',
    'description': 'Utilities for shell-like everyday computery tasks',
    'long_description': None,
    'author': 'Movpasd',
    'author_email': '54367524+movpasd@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
