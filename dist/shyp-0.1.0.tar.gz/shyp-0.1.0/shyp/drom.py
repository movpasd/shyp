"""
Dromedaries!
"""


from abc import ABC, abstractmethod
from typing import Any, Callable, Generic, List, TypeVar, cast


A = TypeVar("A", contravariant=True)
R = TypeVar("R", covariant=True)
newR = TypeVar("newR")


class BaseDrom(Generic[A, R], ABC):
    """
    Base class for droms, a type of callable which can be chained together with others
    """

    @abstractmethod
    def run(self, arg: A) -> R:
        """
        Execute the command that this drom represents
        """
        ...

    def chain(self, other: "BaseDrom[R, newR]") -> "Caravan[A, newR]":
        """
        Default implementation for chaining together two droms. Can be overriden for
        optimisation purposes.
        """

        return Caravan(self, [], other)

    def __ror__(self, lother: A) -> R:
        return self.run(lother)

    def __call__(self, arg: A) -> R:
        return self.run(arg)

    def __rshift__(self, other: "BaseDrom[R, newR]") -> "Caravan[A, newR]":
        return self.chain(other)


class Caravan(BaseDrom[A, R]):
    """
    A `Drom` composed of a chain of sequentially evaluated sub-`Drom`s
    """

    def __init__(
        self,
        first: BaseDrom[A, Any],
        mids: List[BaseDrom[Any, Any]],
        last: BaseDrom[Any, R],
    ):
        """
        The first and last droms are declared separately for static typing reasons.
        This constructor probably shouldn't be called manually anyway.
        """

        self._alldroms = [first] + mids + [last]
        self._first = first
        self._mids = mids
        self._last = last

    # implementation
    def run(self, arg: A) -> R:

        nextval: Any = arg

        for drom in self.droms:
            nextval = drom.run(nextval)

        return cast(R, nextval)

    # override
    def chain(self, other: "BaseDrom[R, newR]") -> "Caravan[A, newR]":

        if isinstance(other, Caravan):
            return Caravan(self.first, self.droms[1:] + other.droms[:-1], other.last)
        else:
            return super().chain(other)

    @property
    def droms(self) -> List[BaseDrom[Any, Any]]:
        """
        All droms in this caravan
        """
        return self._alldroms

    @property
    def first(self) -> BaseDrom[A, Any]:
        """
        The first drom in this caravan
        """
        return self._first

    @property
    def last(self) -> BaseDrom[Any, R]:
        """
        The last drom in this caravan
        """
        return self._last

    @property
    def mids(self) -> List[BaseDrom[Any, Any]]:
        """
        Every drom in this caravan but the first and last
        """
        return self._mids


class DynDrom(BaseDrom[A, R]):
    """
    Drom defined dynamically via a function
    """

    def __init__(self, func: Callable[[A], R]):
        self.func = func

    # implementation
    def run(self, arg: A) -> R:
        return self.func(arg)
